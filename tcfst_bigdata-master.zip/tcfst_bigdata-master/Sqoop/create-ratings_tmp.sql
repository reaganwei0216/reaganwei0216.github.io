CREATE TABLE ratings_tmp (
userid INTEGER,
itemid INTEGER,
ratings INTEGER
);
