CREATE TABLE ratings (
userid INTEGER,
itemid INTEGER,
ratings INTEGER
);
